suppressWarnings(unlink("myfile.geojson"))
suppressWarnings(unlink("myfile.topojson"))
